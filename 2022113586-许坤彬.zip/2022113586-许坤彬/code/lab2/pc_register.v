`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/09/03 16:57:38
// Design Name: 
// Module Name: PC
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



module pc_register(
    input clk,                  // ʱ���ź�
    input [31:0] jmp_addr,      // ��ת����õ��ĵ�ַ
    input jmp,                  // jmpָ���ź�
    input resetn,               //��λ�ź�
    input  [31:0] ID_EX_IR,
    input  [31:0] EX_MEM_IR,
    input  [31:0] predicted_addr,
    input         predicted_success,
    output [31:0] npc,    //��ǰָ���ַ
    output [31:0] pc,      // ��һ��ָ��
    output inst_sram_en,         // �ڴ��ʹ��
    output jmp_reg_sign,
    output [31:0] pc_tmp_reg_value
    );
    
    reg jmp_reg;
    reg [31:0] pc_reg;
    reg [31:0] npc_reg;
    reg [31:0] pc_tmp_reg;
    reg [31:0] predicted_tmp_reg;
    
    assign jmp_reg_sign = jmp_reg; 
    assign pc_tmp_reg_value = pc_tmp_reg;
    
    always @(posedge clk) begin
        // ����λ�ź�Ϊ0����ָ���ַ��λΪ0��npc��λΪ4
        if (!resetn) begin
            pc_reg <= 32'b0;
            npc_reg <= 32'b100;
            jmp_reg <= 0;
            pc_tmp_reg <= 32'b0;
        // һ�������£���Ҫ����npc��ֵ������תֵ����ת��ַ���ж�·ѡ��
        end else begin
            // �����תָ��Ϊ�棬��ô����ID�׶μ���õ���jmp_addr��ֵ��pc
            if (jmp_reg & ~predicted_success ) begin
                jmp_reg <= 0;
                pc_tmp_reg <= 32'b0;
                if (predicted_tmp_reg == 32'b0) begin
                    pc_reg <= npc_reg;
                    npc_reg <= npc_reg +4;
                    
                end else begin
                    predicted_tmp_reg = 32'b0;
                    pc_reg <= pc_tmp_reg + 4;
                    npc_reg <= pc_tmp_reg +8;
                end  
            end else begin
                if (jmp) begin
                    jmp_reg <= jmp;
                    pc_tmp_reg <= jmp_addr;
                    pc_reg <= (predicted_addr == 0) ? jmp_addr : predicted_addr +4 ;
                    npc_reg <= (predicted_addr == 0) ? jmp_addr + 4 : predicted_addr +8 ;
                    predicted_tmp_reg <= predicted_addr;
                end else begin
                    jmp_reg <= 0;
                    if ((EX_MEM_IR[31:26] == 6'b100011 & ID_EX_IR[31:26] == 6'b000000 & (EX_MEM_IR[20:16] == ID_EX_IR[25:21] | EX_MEM_IR[20:16] == ID_EX_IR[20:16])) | 
                        (ID_EX_IR[31:26] == 6'b111111)) begin
                        
                    end else begin
                        //pc_reg <= (predicted_addr == 0) ? npc_reg : predicted_addr +4 ;
                        // npc_reg <= (predicted_addr == 0) ? npc_reg + 4 : predicted_addr +8 ;
                        pc_reg <= npc_reg;
                        npc_reg <= npc_reg + 4;
                    end
                end
            end
        end
    end
    
    // ���Ĵ�����������������
    assign npc = npc_reg;
    assign pc  = pc_reg;
    assign inst_sram_en = ~(EX_MEM_IR[31:26] == 6'b100011 & ID_EX_IR[31:26] == 6'b000000 & (EX_MEM_IR[20:16] == ID_EX_IR[25:21] | EX_MEM_IR[20:16] == ID_EX_IR[20:16]));
    
endmodule


