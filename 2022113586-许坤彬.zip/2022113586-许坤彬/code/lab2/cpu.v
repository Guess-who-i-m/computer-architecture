`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2024/09/03 16:54:07
// Design Name: 
// Module Name: cpu
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module cpu(
    input           clk,                // ʱ���ź�
    input           resetn,             // ����Ч��λ�ź�

    output          inst_sram_en,       // ָ��洢����ʹ��
    output[31:0]    inst_sram_addr,     // ָ��洢������ַ
    input[31:0]     inst_sram_rdata,    // ָ��洢������������

    output          data_sram_en,       // ���ݴ洢���˿ڶ�/дʹ��
    output[3:0]     data_sram_wen,      // ���ݴ洢��дʹ��      
    output[31:0]    data_sram_addr,     // ���ݴ洢����/д��ַ
    output[31:0]    data_sram_wdata,    // д�����ݴ洢��������
    input[31:0]     data_sram_rdata,    // ���ݴ洢������������

    // ���Զ����Ի�������CPU��ȷ�Լ��
    output[31:0]    debug_wb_pc,        // ��ǰ����ִ��ָ���PC
    output          debug_wb_rf_wen,    // ��ǰͨ�üĴ������дʹ���ź�
    output[4:0]     debug_wb_rf_wnum,   // ��ǰͨ�üĴ�����д�صļĴ������
    output[31:0]    debug_wb_rf_wdata   // ��ǰָ����Ҫд�ص�����
);

    
   
    wire [31:0] rdata1; // �Ĵ������˿�1
    
    wire [31:0] rdata2; // �Ĵ������˿�2
    wire we;           // �Ĵ�����дʹ��

    wire [31:0] wdata; // �Ĵ���д����
    wire [31:0] wdata_cmp; // cmpָ���µ�д������
    
    
    wire invalid;            // ��Чָ���־

        // ID/EX�μ�Ĵ���
    reg [31:0] ID_EX_npc;
    reg [31:0] ID_EX_IR;
    reg        ID_EX_we;
    reg [4:0]  ID_EX_waddr;          // �Ĵ���д��Ҫ������ϸ����
    reg        ID_EX_alu_en;         //������MEM/WB�׶��ж�д��ʲô����
    reg [4:0]  ID_EX_alu_card;       // ��EXE�׶���alu��ȷ����
    reg        ID_EX_data_sram_en;
    reg [3:0]  ID_EX_data_sram_wen;
    reg        ID_EX_movz_en;
    reg        ID_EX_sll_en;
    reg        ID_EX_cmp_en;
    reg [31:0] ID_EX_rdata1;
    reg [31:0] ID_EX_rdata2;
    reg [31:0] ID_EX_pc;
    reg        ID_EX_invalid;
    
    // EX/MEM
    reg [31:0]  EX_MEM_IR;
    reg         EX_MEM_we;
    reg         EX_MEM_movz_en;
    reg [4:0]   EX_MEM_waddr;
    reg         EX_MEM_sll_en;
    reg         EX_MEM_cmp_en;
    reg         EX_MEM_alu_en;
    reg [31:0]  EX_MEM_alu_out;
    reg [31:0]  EX_MEM_rdata1;
    reg [31:0]  EX_MEM_rdata2;
    reg         EX_MEM_data_sram_en;
    reg [3:0]   EX_MEM_data_sram_wen;
    reg [31:0]  EX_MEM_pc;
    reg         EX_MEM_invalid;
    reg [31:0]  EX_MEM_wdata_cmp;
    reg [31:0]  EX_MEM_data_sram_addr;
    reg [31:0]  EX_MEM_data_sram_wdata;
    reg [31:0]  EX_MEM_alu_data1;
    reg [31:0]  EX_MEM_alu_data2;
    
    // MEM/WB
    reg         MEM_WB_movz_en;
    reg         MEM_WB_alu_en;
    reg [31:0]  MEM_WB_alu_out;
    reg [31:0]  MEM_WB_rdata1;
    reg [31:0]  MEM_WB_rdata2;
    reg [31:0]  MEM_WB_IR;
    reg         MEM_WB_cmp_en;
    reg         MEM_WB_sll_en;
    reg         MEM_WB_data_sram_en;
    reg [3:0]   MEM_WB_data_sram_wen;
    reg         MEM_WB_we;
    reg [4:0]   MEM_WB_waddr;
    reg [31:0]  MEM_WB_pc;
    reg         MEM_WB_invalid;
    reg [31:0]  MEM_WB_data_sram_rdata;
    reg [31:0]  MEM_WB_wdata;
    reg [31:0]  MEM_WB_data_sram_addr;
    reg [31:0]  MEM_WB_data_sram_wdata;
    
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////     IF   ////////////////////////////////
    // IF����Ҫ�����£�ȡ��ָ�����ָ��洢��������npc
    //////////////////////////////////////////////////////////////////////////////
    
    // ������������1.ʹ���ź��ܲ���һֱ�趨Ϊ1
    // 2. �ǲ����趨��̫��Ĵ�������һ��ʱ�����ڶ�������
    
    wire [31:0] jmp_addr;       // ��ID�׶νӹ�����������ת��ַ
    wire jmp;                   // ��ID�׶δ������������ж��ǲ���Ҫ��ת
    wire [31:0] pc;
    wire [31:0] IF_ID_npc;
    wire [31:0] IF_ID_IR;
    wire [31:0] npc;
    wire bbt;               // bbt�ź�
    
    wire [31:0] predicted_addr;
    wire jmp_reg_sign;
    wire [31:0] pc_tmp_reg_value;
    
    // ��������������ڼ�¼ָ���ַ
    // �ڲ��������Ĵ������ֱ���npc��pc
    // ���������źţ��ж��ǲ��Ƿ�����LW��ADD��֮����취ֹͣһ����ȡ��ָ�ָֹͣ���������ĸ���
    pc_register u_pc_register(
        .clk            (clk),          // ������ˮ�߹�
        .jmp_addr       (jmp_addr),     // ��ID���ܵõ�       
        .jmp            (jmp),          // ��ID���ܵõ�
        .resetn         (resetn),       // ��λ�ź�
        .predicted_addr (predicted_addr),
        .predicted_success (predicted_success),
        .npc            (npc),          // pc + 4
        .pc             (pc),          // ָ���ַ
        .inst_sram_en   (inst_sram_en),  // ָ��洢����ʹ��
        .EX_MEM_IR      (ID_EX_IR),
        .ID_EX_IR       (IF_ID_IR),
        .jmp_reg_sign   (jmp_reg_sign),
        .pc_tmp_reg_value   (pc_tmp_reg_value)
    );
    

   
    wire judge;
    assign judge = (ID_EX_IR[31:26] == 6'b111111);
   
    // assign inst_sram_addr = (predicted_addr == 0) ? pc : predicted_addr;
    assign inst_sram_addr = ({32{ (predicted_addr == 32'b0) & ~jmp_reg_sign}} & pc) |
                            ({32{ (predicted_addr == 32'b0) &  jmp_reg_sign & ~predicted_success}} & pc_tmp_reg_value) |
                            ({32{ (predicted_addr == 32'b0) &  jmp_reg_sign & predicted_success}} & pc) |
                            // ({32{~(predicted_addr == 32'b0) & }} & pc) |
                            ({32{~(predicted_addr == 32'b0) & ~bbt}} & pc) |
                            ({32{~(predicted_addr == 32'b0) &  bbt }} & predicted_addr);
//    assign inst_sram_addr = ({32{~(predicted_addr == 32'b0) & ~jmp_reg_sign}} & predicted_addr) |
//                            ({32{~(predicted_addr == 32'b0) &  jmp_reg_sign}} & pc_tmp_reg_value) |
//                            ({32{(predicted_addr == 32'b0) }} & pc);
    assign IF_ID_npc = npc;
    assign IF_ID_IR =  {32{(~judge) | (judge & predicted_success)}} & inst_sram_rdata;
  
      
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////    ID   ////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////   

    wire we_decoder;        // ָ��������������дʹ��
    wire [4:0] waddr;       // �Ĵ���д��ַ
    wire [4:0]  raddr1;     //�Ĵ�������ַ1
    wire [4:0]  raddr2;     //�Ĵ�������ַ2
    wire alu_en;            // aluʹ��
    wire [4:0] alu_card;    // alu��������
    // jmp��ID�α�����
    wire sram_en;           // �����Ż���ʽ��������ź�
    wire [3:0]  sram_wen; 
    wire movz_en;           // movzָ���ʹ��
    wire sll_en;            // sllָ���ʹ��
    wire cmp_en;            // cmpָ���ʹ��
    wire [4:0] mem_wb_waddr;
    wire mem_wb_we;
    
    


    // ָ��������
    // û���ڲ������κζμ�Ĵ�������Ҫ��������и���
    inst_decoder u_inst_decoder(
        //input
        .inst       (IF_ID_IR),     // ָ��Ĵ�������Ҫ����ȥ
        .clk        (clk),          // ʱ�ӣ�������ˮ�߹�
        //output
        .wen        (we_decoder),   // �Ĵ���д���ܵ��߼�
        .waddr      (waddr),        // �Ĵ���д��ַ
        .raddr1     (raddr1),       // �Ĵ�������ַ1
        .raddr2     (raddr2),       // �Ĵ�������ַ2
        .alu_en     (alu_en),       // aluʹ��
        .alu_card   (alu_card),     // aluִ����
        .jmp        (jmp),          // jָ��ʹ��
        .bbt        (bbt),          // bbtָ��ʹ��    
        .data_sram_en   (sram_en), //���ݴ洢��ʹ��
        .data_sram_wen  (sram_wen),// ���ݴ洢��дʹ��
        .movz_en        (movz_en),      // movzʹ��
        .sll_en         (sll_en),       // sllʹ��
        .cmp_en         (cmp_en),        // cmpʹ��
        .invalid        (invalid)       // invalid
    );
    
    
    
    // �Ĵ�����
    regfile u_regfile(
        .clk        (clk),
        .raddr1     (raddr1),
        .rdata1     (rdata1),
        .raddr2     (raddr2),
        .rdata2     (rdata2),
        .we         (mem_wb_we),
        .waddr      (mem_wb_waddr),
        .wdata      (wdata)
    );
    
    // ����һָ��Ϊcmp,��ָ��Ϊbbt������£�rdata1���ܴӼĴ�����ȡ������Ҫwdata_cmp��ֱ��ȡ����
    wire [31:0] bbt_data1;
    wire judge1 = (IF_ID_IR[31:26] == 6'b111111) & (ID_EX_IR[31:26] == 6'b111110) & (IF_ID_IR[25:21] == ID_EX_IR[15:11]);
    assign bbt_data1 = ({32{judge1}} & wdata_cmp) | ({32{~judge1}} & rdata1);
                        
    
    // ������ת��ַ
    addr_calculator u_addr_calculator(
        .clk        (clk),
        .npc        (ID_EX_npc),
        .inst       (IF_ID_IR),
        .rdata1     (bbt_data1),
        .raddr2     (raddr2),
        .jmp        (jmp),
        .bbt        (bbt),
        .jmp_addr   (jmp_addr)
    );
    
    
     branch u_branch(
        .clk                (clk),
        .resetn             (resetn),
        .pc                 (pc),
        .bbt                (bbt),
        .jmp_addr           (jmp_addr),
        .predicted_addr     (predicted_addr),
        .predicted_success  (predicted_success)
    );

    
    always @(posedge clk) begin
    
        // ��ˮ����
        if ((ID_EX_IR[31:26] == 6'b100011 & IF_ID_IR[31:26] == 6'b000000 & (ID_EX_IR[20:16] == IF_ID_IR[25:21] | ID_EX_IR[20:16] == IF_ID_IR[20:16]))) begin
            ID_EX_IR <= 32'b0;
            ID_EX_we <= 0 ;
            ID_EX_waddr <= 0;
            ID_EX_alu_en <= 0;
            ID_EX_alu_card <= 0;
            ID_EX_data_sram_en <= 0;
            ID_EX_data_sram_wen <= 0;
            ID_EX_sll_en <= 0;
            ID_EX_cmp_en <= 0;
            ID_EX_rdata1 <= 0;
            ID_EX_rdata2 <= 0;
            // ID_EX_pc     <= 0;
            ID_EX_invalid<= 1;
            ID_EX_movz_en<= 0;
        end else begin
            ID_EX_npc <= IF_ID_npc;
            ID_EX_IR <= IF_ID_IR;
            ID_EX_we <= we_decoder ;
            ID_EX_waddr <= waddr;
            ID_EX_alu_en <= alu_en;
            ID_EX_alu_card <= alu_card;
            ID_EX_data_sram_en <= sram_en;
            ID_EX_data_sram_wen <= sram_wen;
            ID_EX_sll_en <= sll_en;
            ID_EX_cmp_en <= cmp_en;
            ID_EX_rdata1 <= rdata1;
            ID_EX_rdata2 <= rdata2;
            // ID_EX_pc     <= pc;
            // ID_EX_pc     <= (predicted_addr == 0) ? pc : predicted_addr;
            ID_EX_pc     <=  inst_sram_addr;
            ID_EX_invalid<= invalid;
            ID_EX_movz_en<= movz_en;
        end
    end
    
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////     EX   ////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    
    // ����ֱ�ӿ���ͨ����������
    wire    [31:0]      alu_data1;
    wire    [31:0]      alu_data2;
    
    
    assign alu_data1 = ({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b000000) }} & EX_MEM_alu_out)  | 
                       ({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b111110) }} & EX_MEM_wdata_cmp)| 
                       ({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == MEM_WB_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (MEM_WB_IR[31:26] == 6'b000000) }} & MEM_WB_wdata)         & ~({32{(ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b000000) }}) & ~({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b111110) }} )   | 
                       ({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == MEM_WB_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (MEM_WB_IR[31:26] == 6'b111110) }} & MEM_WB_wdata)           & ~({32{(ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b111110) }}) & ~({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b000000) }})  | 
                       ({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == MEM_WB_IR[20:16]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (MEM_WB_IR[31:26] == 6'b100011) }} & MEM_WB_data_sram_rdata) & ~({32{(ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b000000) }}) & ~({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (EX_MEM_IR[31:26] == 6'b111110) }} ) |
                       (ID_EX_rdata1 & ~({32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == EX_MEM_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & ((EX_MEM_IR[31:26] == 6'b000000) | (EX_MEM_IR[31:26] == 6'b111110)) }} | {32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == MEM_WB_IR[15:11]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & ((MEM_WB_IR[31:26] == 6'b000000) | (MEM_WB_IR[31:26] == 6'b111110)) }} | {32{(ID_EX_IR[25:21] != 0) & (ID_EX_IR[25:21] == MEM_WB_IR[20:16]) & ((ID_EX_IR[31:26] == 6'b000000) | (ID_EX_IR[31:26] == 6'b101011) | (ID_EX_IR[31:26] == 6'b100011) | (ID_EX_IR[31:26] == 6'b111111) ) & (MEM_WB_IR[31:26] == 6'b100011) }})) ;
                       
    assign alu_data2 = ({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b000000) }} & EX_MEM_alu_out)  | 
                       ({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b111110) }} & EX_MEM_wdata_cmp)  |
                       ({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == MEM_WB_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (MEM_WB_IR[31:26] == 6'b000000) }} & MEM_WB_wdata)         & ~({32{(ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b000000) }}) & ~({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b111110) }} ) |
                       ({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == MEM_WB_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (MEM_WB_IR[31:26] == 6'b111110) }} & MEM_WB_wdata)           & ~({32{(ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b111110) }})   & ~({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b000000) }} ) |  
                       ({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == MEM_WB_IR[20:16]) & (ID_EX_IR[31:26] == 6'b000000) & (MEM_WB_IR[31:26] == 6'b100011) }} & MEM_WB_data_sram_rdata )& ~({32{(ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b000000) }}) & ~({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & (EX_MEM_IR[31:26] == 6'b111110) }}) |
                       (ID_EX_rdata2 & ~({32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & ((EX_MEM_IR[31:26] == 6'b000000) | (EX_MEM_IR[31:26] == 6'b111110) ) }} | {32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == MEM_WB_IR[15:11]) & (ID_EX_IR[31:26] == 6'b000000) & ((MEM_WB_IR[31:26] == 6'b000000)| (MEM_WB_IR[31:26] == 6'b111110)) }} | {32{(ID_EX_IR[20:16] != 0) & (ID_EX_IR[20:16] == MEM_WB_IR[20:16]) & (ID_EX_IR[31:26] == 6'b000000) & (MEM_WB_IR[31:26] == 6'b100011) }}));
    

    
    wire [31:0] alu_out_part;
    wire [31:0] alu_out;
    wire [31:0] cmp_data1;
    wire [31:0] cmp_data2;
    
    my_alu u_alu(
        .A          (alu_data1),
        .B          (alu_data2),
        .Cin        (0     ),
        .Card       (ID_EX_alu_card),
        .F          (alu_out_part)
    );
    
                                                  // ({32{EX_MEM_sll_en}} & (EX_MEM_alu_data2 << EX_MEM_IR[10:6])) | 
    assign alu_out =({32{~ID_EX_sll_en}} & alu_out_part) | ({32{ID_EX_sll_en}} & (alu_data2 << ID_EX_IR[10:6]));
    
    // ��ִ�н׶���ǰ�����ݴ洢����Ҫ���ڴ��дʹ�ܸ���ȥ
    assign data_sram_en = ID_EX_data_sram_en;
    assign data_sram_wen = ID_EX_data_sram_wen;
    
    // ���ݴ洢���ڴ����ַ����Ҫ���ݵ�MEM�׶�
    assign data_sram_addr = {32{ID_EX_data_sram_en & ~((EX_MEM_data_sram_en == 1) & (EX_MEM_data_sram_wen != 4'b1111) & ID_EX_IR[25:21] == EX_MEM_IR[20:16] )}} & (alu_data1 + {{16{ID_EX_IR[15]}}, ID_EX_IR[15:0]})     |
                            {32{ID_EX_data_sram_en &  ((EX_MEM_data_sram_en == 1) & (EX_MEM_data_sram_wen != 4'b1111) & ID_EX_IR[25:21] == EX_MEM_IR[20:16] )}} & (data_sram_rdata + {{16{ID_EX_IR[15]}}, ID_EX_IR[15:0]}) ;    //sw��lw
    // ���ݴ洢����д������ݣ���Ҫ���ݵ�MEM�׶�
    assign data_sram_wdata = ({32{(ID_EX_data_sram_wen == 4'b1111) & ((ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (EX_MEM_IR[31:26] == 6'b000000 ))}} & EX_MEM_alu_out)  |
                             ({32{(ID_EX_data_sram_wen == 4'b1111) & ((ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (EX_MEM_IR[31:26] == 6'b111110 ))}} & EX_MEM_wdata_cmp)  |
                             {32{(ID_EX_data_sram_wen == 4'b1111) & ~((ID_EX_IR[20:16] == EX_MEM_IR[15:11]) & (EX_MEM_IR[31:26] == 6'b000000 | EX_MEM_IR[31:26] == 6'b111110))}} & ID_EX_rdata2;

    
    // ��cmp��ص����ݳ�ͻ
    assign cmp_data1 = ({32{(EX_MEM_IR[31:26] == 6'b000000) & (EX_MEM_IR[15:11] == ID_EX_IR[25:21])}} & EX_MEM_alu_out) | ( (~{32{(EX_MEM_IR[31:26] == 6'b000000) & (EX_MEM_IR[15:11] == ID_EX_IR[25:21])}}) & ID_EX_rdata1);
    assign cmp_data2 = ({32{(EX_MEM_IR[31:26] == 6'b000000) & (EX_MEM_IR[15:11] == ID_EX_IR[20:16])}} & EX_MEM_alu_out) | ( (~{32{(EX_MEM_IR[31:26] == 6'b000000) & (EX_MEM_IR[15:11] == ID_EX_IR[20:16])}}) & ID_EX_rdata2);
    
    
    assign wdata_cmp = {32{ID_EX_cmp_en}} & { {22{1'b0}}, ~(cmp_data1 <= cmp_data2) , ~($signed(cmp_data1) <= $signed(cmp_data2)) ,~(cmp_data1 < cmp_data2) , ~($signed(cmp_data1) < $signed(cmp_data2)) ,~(cmp_data1 == cmp_data2) ,(cmp_data1 <= cmp_data2) ,($signed(cmp_data1) <= $signed(cmp_data2)) ,(cmp_data1 < cmp_data2) , ($signed(cmp_data1) < $signed(cmp_data2)) ,(cmp_data1 == cmp_data2)};
    
    always @(posedge clk) begin
    
        // �Ĵ������������£����漰��·
        EX_MEM_IR               <=  ID_EX_IR;
        EX_MEM_we               <=  ID_EX_we;
        EX_MEM_waddr            <=  ID_EX_waddr;
        EX_MEM_movz_en          <=  ID_EX_movz_en;
        EX_MEM_sll_en           <=  ID_EX_sll_en;
        EX_MEM_cmp_en           <=  ID_EX_cmp_en;
        EX_MEM_alu_out          <=  alu_out; 
        EX_MEM_rdata1           <=  ID_EX_rdata1;
        EX_MEM_rdata2           <=  ID_EX_rdata2;
        EX_MEM_data_sram_en     <=  ID_EX_data_sram_en;
        EX_MEM_data_sram_wen    <=  ID_EX_data_sram_wen;
        EX_MEM_alu_en           <=  ID_EX_alu_en;
        EX_MEM_pc               <=  ID_EX_pc;
        EX_MEM_invalid          <=  ID_EX_invalid;
        EX_MEM_wdata_cmp        <=  wdata_cmp;
        EX_MEM_data_sram_addr   <=  data_sram_addr;
        EX_MEM_data_sram_wdata  <=  data_sram_wdata;
        EX_MEM_alu_data1        <=  alu_data1;
        EX_MEM_alu_data2        <=  alu_data2;

        
    end
    
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////     MEM   ///////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    
    wire we_movz;      // movzָ�������дʹ��
    assign we_movz = ((EX_MEM_IR[20:16] != MEM_WB_IR[15:11]) & (EX_MEM_rdata2 == 32'b0) & EX_MEM_movz_en) |
                      ((EX_MEM_IR[20:16] == MEM_WB_IR[15:11]) & (MEM_WB_wdata == 32'b0) & EX_MEM_movz_en);
    
    assign mem_wb_we = (EX_MEM_we | we_movz) & ~EX_MEM_invalid;       // ������û�����Ĵ���������ֻ���жϲ���дʹ�� 
    assign mem_wb_waddr = EX_MEM_waddr;
    // ����ʱ��
    assign wdata = (({32{ ~((MEM_WB_data_sram_wen == 4'b1111)& ~((MEM_WB_data_sram_en == 1) & (MEM_WB_data_sram_addr == EX_MEM_IR[20:16])) & (MEM_WB_data_sram_addr == EX_MEM_data_sram_addr)) & EX_MEM_data_sram_en & ~(EX_MEM_data_sram_wen == 4'b1111)}} & data_sram_rdata) |         // һ����ڴ��
                   ({32{ ((MEM_WB_data_sram_wen == 4'b1111) & (MEM_WB_data_sram_addr == EX_MEM_data_sram_addr)) & EX_MEM_data_sram_en & ~(EX_MEM_data_sram_wen == 4'b1111)}} & MEM_WB_data_sram_wdata) |    // sw����ڴ��
                   ({32{EX_MEM_alu_en}} & EX_MEM_alu_out) | 
                   ({32{we_movz}} & EX_MEM_alu_data1) |  
                   ({32{EX_MEM_cmp_en}} & EX_MEM_wdata_cmp)) & {32{~EX_MEM_invalid}};
                        
    
    
    
    always @(posedge clk) begin
        MEM_WB_movz_en  <=  EX_MEM_movz_en;
        MEM_WB_alu_en   <=  EX_MEM_alu_en;
        MEM_WB_alu_out  <=  EX_MEM_alu_out;
        MEM_WB_rdata1   <=  EX_MEM_rdata1;
        MEM_WB_rdata2   <=  EX_MEM_rdata2;
        MEM_WB_IR       <=  EX_MEM_IR;
        MEM_WB_cmp_en   <=  EX_MEM_cmp_en;
        MEM_WB_movz_en  <=  EX_MEM_movz_en;
        MEM_WB_sll_en   <=  EX_MEM_sll_en;
        MEM_WB_we       <=  EX_MEM_we;
        MEM_WB_data_sram_en     <=  EX_MEM_data_sram_en;
        MEM_WB_data_sram_wen    <=  EX_MEM_data_sram_wen;
        MEM_WB_waddr            <=  EX_MEM_waddr;
        MEM_WB_pc               <=  EX_MEM_pc;
        MEM_WB_invalid          <=  EX_MEM_invalid;
        MEM_WB_data_sram_rdata  <=  data_sram_rdata;
        MEM_WB_wdata            <=  wdata;
        MEM_WB_data_sram_addr   <=  EX_MEM_data_sram_addr;
        MEM_WB_data_sram_wdata  <=  EX_MEM_data_sram_wdata;
    end
    
    //////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////     WB   ////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////
    
    
    
    assign debug_wb_pc = MEM_WB_pc;
    assign debug_wb_rf_wen = mem_wb_we;
    assign debug_wb_rf_wnum = mem_wb_waddr;
    assign debug_wb_rf_wdata = wdata;
    
endmodule
